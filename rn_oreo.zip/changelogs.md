v2.1.1
- Fixed: layout product list in home
- Fixed: blog grid in home

v2.1.0
- Improved: CART REST API work with Mobile builder v1.1.4
- Chore: remove show error in home get product and vendor

v2.0.4
- Chore: go policy by in payment
- Fix: data vendor null
- Chore: set loading webview checkout
- Updated: translate file en.json

v2.0.3
- Updated: Splash screen for Android

v2.0.2
- Fixed: outstock in list product in store
- Fixed: add to cart with product variation

v2.0.1
- Fixed: Check phone in register and login SMS
- Fixed: Config Firebase for Android

v2.0.0
- Changed: Update React native v0.62.0
- Changed: Update React navigation v5.x.x
- Changed: Cart REST API for custom flow checkout
- Changed: Use Mobile-builder plugin instead rnlab-app-control
- Added: Support WCFM vendor plugin
- Improvement: Splash screen on Android
- Improvement: Cached config builder and categories
- Improvement: Colors style template
- Improvement: Checkout webview token expired
- Fixed: variations in product detail
- Fixed: Query search
- Fixed: Click item sort by in refine screen
