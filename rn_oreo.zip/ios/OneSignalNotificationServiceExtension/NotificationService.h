//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Dang Ngoc on 6/9/20.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
