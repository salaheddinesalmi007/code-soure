import {Image, ImageBackground} from 'react-native';

const BackgroundImage = ImageBackground || Image;

export default BackgroundImage;
