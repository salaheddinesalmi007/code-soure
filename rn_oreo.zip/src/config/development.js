export const ENABLE_CONFIG_DEMO = false;
export const VENDOR = 'wcfm'; // Enum ['wcfm', 'dokan']
export const PLUGIN_NAME = 'mobile-builder';
