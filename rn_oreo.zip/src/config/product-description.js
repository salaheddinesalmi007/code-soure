export const ENABLE_WEBVIEW = false;
