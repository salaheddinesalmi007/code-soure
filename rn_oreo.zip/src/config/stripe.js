export const PUBLISHABLE_KEY = 'pk_test_m0D51wLcsdUSafjGsYVNiVJU00coyhxY3c';
